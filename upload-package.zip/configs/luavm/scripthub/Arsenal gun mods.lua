local weapons = game:GetService("ReplicatedStorage").Weapons

for _, w in ipairs(weapons:GetChildren()) do
    pcall(function()
        for _, v in ipairs(w:GetChildren()) do
            if v.Name == "ReloadTime" then
                v.Value = 0
            elseif v.Name == "FireRate" then
                v.Value = 0
            elseif v.Name == "Auto" then
                v.Value = true
            elseif v.Name == "MaxSpread" then
                v.Value = 0
            elseif v.Name == "RecoilControl" then
                v.Value = 0
            end
        end
    end)
end