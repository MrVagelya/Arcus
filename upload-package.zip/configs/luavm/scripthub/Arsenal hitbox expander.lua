local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local HitboxSize = 20 --hitbox size you can set it up to a max of 50 over that it wont work
RunService.Heartbeat:Connect(function()
    for _, Player in Players:GetPlayers() do
        local Character = Player.Character
        if not Character then
            continue
        end
        local HeadHB = Character:FindFirstChild("HeadHB")
        if not HeadHB or not HeadHB:IsA("BasePart") then
            continue
        end
        HeadHB.Size = Vector3.new(HitboxSize, HitboxSize, HitboxSize)
        HeadHB.CanCollide = false
    end
end)