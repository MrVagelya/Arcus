-- One of: "MouseKeyboard", "Touch", "Gamepad", "VR"
local device = "MouseKeyboard"
game:GetService("ReplicatedStorage").Remotes.Replication.Fighter.SetControls:FireServer(device)
