-- One of: "MouseKeyboard", "Touch", "Gamepad", "VR"
local device = "Touch"
game:GetService("ReplicatedStorage").Remotes.Replication.Fighter.SetControls:FireServer(device)
