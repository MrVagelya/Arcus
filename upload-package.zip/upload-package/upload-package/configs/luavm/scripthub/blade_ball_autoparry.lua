if game.GameId ~= 4777817887 then
	notify("This script only runs in Blade Ball.", "bladeball autoparry", 4)
	return
end

local old = getgenv().BBX
if old then pcall(old.unload) end

local lp = game.Players.LocalPlayer
local camera = workspace.CurrentCamera
local BBX = { draw = {}, conns = {} }
getgenv().BBX = BBX

local hostUI = UI
local settings = getgenv().BladeSettings or {
	bbx_on = true, bbx_input_v3 = 0, bbx_key = 0,
	bbx_curve_v4 = false, bbx_play_v4 = false, bbx_hud = true, bbx_keys_visible = true,
	bbx_hudpos = 0, bbx_ball = true, bbx_ring = false, bbx_offset = 43, bbx_ping = true,
	bbx_move = true, bbx_zbase = 10, bbx_zspd = 6,
	bbx_minspd = 6, bbx_range_on = false, bbx_range = 25, bbx_range_ring = false,
	bbx_log = true, bbx_curve_side = 0, bbx_curve_angle = 25, bbx_spacing = 18
}
if not settings.timingProfileV5 then
	if settings.bbx_zbase == 18 and settings.bbx_zspd == 12 and settings.bbx_offset == 0 then
		settings.bbx_zbase, settings.bbx_zspd, settings.bbx_offset = 10, 6, 43
	end
	settings.timingProfileV5 = true
end
settings.bbx_clash_v3, settings.bbx_clash_rate_v3 = nil, nil
getgenv().BladeSettings = settings
local binds = getgenv().BladeBinds or {
	menu = "RightShift", parry = "F6", hud = "F8", play = "F9"
}
binds.clash = nil
getgenv().BladeBinds = binds
local UI = {
	GetValue = function(key) return settings[key] end,
	SetValue = function(key, value) settings[key] = value end
}
local ACCENT = Color3.fromRGB(139, 172, 255)
local KEYS = { "F", "Q", "E", "R", "Z", "X", "C" }
local function parryKeyArg(name)
	if Enum and Enum.KeyCode and Enum.KeyCode[name] then
		return Enum.KeyCode[name]
	end
	return name
end
for _, tab in ipairs({"Play", "Tune", "Movement", "Keys", "Control", "Timing", "Visuals", "Session", "Keybinds"}) do
	pcall(hostUI.RemoveTab, tab)
end
pcall(function() hostUI.SetAutoOpen(false) end)
pcall(function() hostUI.SetOverlayButton(false) end)
local menuOpen = false
local function setMenu(open)
	menuOpen = open and true or false
	pcall(function() hostUI.SetMenuOpen(menuOpen) end)
end
setMenu(false)

local cfg = {}
local function refresh()
	cfg.on = UI.GetValue("bbx_on") ~= false
	cfg.input = (UI.GetValue("bbx_input_v3") or 0) + 1
	cfg.key = KEYS[(UI.GetValue("bbx_key") or 0) + 1] or "F"
	cfg.rangeOn = UI.GetValue("bbx_range_on") == true
	cfg.range = UI.GetValue("bbx_range") or 25
	cfg.rangeRing = UI.GetValue("bbx_range_ring") ~= false
	cfg.offset = (UI.GetValue("bbx_offset") or 43) / 1000
	cfg.ping = UI.GetValue("bbx_ping") ~= false
	cfg.move = UI.GetValue("bbx_move") ~= false
	cfg.log = UI.GetValue("bbx_log") ~= false
	cfg.zbase = UI.GetValue("bbx_zbase") or 10
	cfg.zspd = (UI.GetValue("bbx_zspd") or 6) / 100
	cfg.minspd = UI.GetValue("bbx_minspd") or 6
	cfg.hud = UI.GetValue("bbx_hud") ~= false
	cfg.hudBottom = (UI.GetValue("bbx_hudpos") or 0) == 1
	cfg.ring = UI.GetValue("bbx_ring") ~= false
	cfg.ball = UI.GetValue("bbx_ball") ~= false
	cfg.notify = false
 cfg.showKeys = UI.GetValue("bbx_keys_visible") ~= false
	cfg.accent = ACCENT
	cfg.curve = UI.GetValue("bbx_curve_v4") == true
	cfg.curveSide = UI.GetValue("bbx_curve_side") or 0
	cfg.curveAngle = UI.GetValue("bbx_curve_angle") or 25
	cfg.autoPlay = UI.GetValue("bbx_play_v4") == true
	cfg.spacing = UI.GetValue("bbx_spacing") or 18
end
refresh()

local S = {
	ok = 0, fail = 0, presses = 0, adapt = 0, confirmSum = 0, confirmN = 0,
	rtt = 0.05, pingAt = 0, keyDown = false, keyAt = 0, keyName = "F", keyMode = 0,
	lastPress = -math.huge, armed = true, pending = nil, wasTargeted = false, status = "IDLE",
 unknown = 0, approach = nil, departed = false, lostTargetAt = nil, releasedAt = nil,
	myVel = Vector3.zero, lastCounter = nil, flash = 0, flashOk = true,
}

local function robloxInput(on)
	if setrobloxinput then pcall(setrobloxinput, on and true or false) end
end

local function sendParryKey(down)
	local key = parryKeyArg(S.keyName or cfg.key or "F")
	robloxInput(false)
	if down then keypress(key) else keyrelease(key) end
end

local function tapParryKey(now)
	sendParryKey(true)
	sendParryKey(false)
	S.keyDown = false
	S.lastKeyRelease = now or os.clock()
end

BBX.controls = { settings = settings, binds = binds, open = setMenu }
S.trace = {}
local function captureFailure(reason)
	local frames = {}
	for i, frame in ipairs(S.trace) do frames[i] = frame end
	S.lastFailure = { reason = reason, frames = frames }
end
local history = {}
local function remember(entry)
	history[#history + 1] = entry
	if #history > 8 then table.remove(history, 1) end
	return entry
end
local function historyText(now)
	local parts = {}
	for i = math.max(1, #history - 3), #history do
		local h = history[i]
		parts[#parts + 1] = string.format("[%.0f ms ago %s d=%.0f spd=%.0f tZone=%.0f -> %s]", (now - h.t) * 1000, h.why or "?", h.d or -1, h.s or -1, math.min(h.tz or 9.99, 9.99) * 1000, h.out or "pending")
	end
	return table.concat(parts, " ")
end

local movementKeys = {}
local function stopMovement()
	for key in pairs(movementKeys) do keyrelease(key) end
	movementKeys = {}
end

local function opponentAt(position)
	local nearest, distance = nil, math.huge
	local character = lp.Character
	local function consider(point)
		local d = (point - position).Magnitude
		if d > 0.5 and d < distance then nearest, distance = point, d end
	end
	if PlayerCache then
		for _, player in ipairs(PlayerCache.GetPlayers()) do
			if not player.IsLocal and (player.Health or 0) > 0 and player.Position then consider(player.Position) end
		end
	end
	local alive = workspace:FindFirstChild("Alive")
	if alive then
		for _, model in ipairs(alive:GetChildren()) do
			if not character or model.Address ~= character.Address then
				local root = model:FindFirstChild("HumanoidRootPart")
				local humanoid = model:FindFirstChildOfClass("Humanoid")
				if root and humanoid and humanoid.Health > 0 then consider(root.Position) end
			end
		end
	end
	return nearest, distance
end

local function restoreCamera()
	if S.curveCamera and S.curveOriginalType ~= nil then
		pcall(function() S.curveCamera.CameraType = S.curveOriginalType end)
	end
	S.curveCamera, S.curveOriginalType, S.curveOffset = nil, nil, nil
end

local function curveAim()
	if not cfg.curve or not camera then restoreCamera() return end
	local character = lp.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not root then restoreCamera() return end
	local target = opponentAt(root.Position)
	if not target then return end
	if S.curveCamera ~= camera then
		restoreCamera()
		S.curveCamera, S.curveOriginalType = camera, camera.CameraType
		S.curveOffset = camera.CFrame.Position - root.Position
	end
	local toTarget = target - root.Position
	local flat = Vector3.new(toTarget.X, 0, toTarget.Z)
	if flat.Magnitude < 1 then return end
	local sideways = Vector3.new(-flat.Z, 0, flat.X) / flat.Magnitude
	local sign = cfg.curveSide == 1 and -1 or cfg.curveSide == 2 and 1 or (S.curveSign or 1)
	local offset = math.tan(math.rad(cfg.curveAngle)) * math.min(flat.Magnitude, 35)
	camera.CameraType = 6
	camera.CFrame = CFrame.lookAt(root.Position + S.curveOffset, target + sideways * (sign * offset))
end

local function safeDirection(position, direction)
	if not Raycast then return false end
	local side = Vector3.new(-direction.Z, 0, direction.X)
	local distance = 6
	for _, height in ipairs({-1.2, 0.5}) do
		for _, width in ipairs({-1.1, 0, 1.1}) do
			local origin = position + Vector3.new(0, height, 0) + side * width
			local hit = Raycast(origin, direction, distance)
			if hit and hit.Distance < distance then return false end
		end
	end
	local ahead = position + direction * distance
	local ground = Raycast(ahead + Vector3.new(0, 2, 0), Vector3.new(0, -1, 0), 10)
	return ground ~= nil and ground.Position ~= nil
		and ground.Position.Y <= position.Y + 0.5 and ground.Position.Y >= position.Y - 6
end

local function autoPlay(now, root, alive, best, targeted, focused)
	if not cfg.on or not cfg.autoPlay or not focused or not alive or not root or not camera then
		stopMovement()
		S.navigation = cfg.autoPlay and "Paused" or "Off"
		return
	end
	if targeted and best and best.tClose < 0.22 then
		stopMovement()
		S.navigation = "Holding for parry"
		return
	end
	if now < (S.nextNavigation or 0) then return end
	S.nextNavigation = now + 0.1
	local position = root.Position
	local target = opponentAt(position)
	if not target then stopMovement() S.navigation = "No opponent" return end
	local away = position - target
	away = Vector3.new(away.X, 0, away.Z)
	if away.Magnitude < 0.1 then stopMovement() S.navigation = "Holding" return end
	local goal = target + away / away.Magnitude * cfg.spacing
	local offset = goal - position
	offset = Vector3.new(offset.X, 0, offset.Z)
	if offset.Magnitude < 2.5 then stopMovement() S.navigation = "In position" return end

	local forward = Vector3.new(camera.CFrame.LookVector.X, 0, camera.CFrame.LookVector.Z)
	if forward.Magnitude < 0.1 then stopMovement() return end
	forward = forward / forward.Magnitude
	local right = Vector3.new(-forward.Z, 0, forward.X)
	local desired = offset / offset.Magnitude
	local candidates = {}
	for _, degrees in ipairs({0, 35, -35, 70, -70, 105, -105}) do
		local angle = math.rad(degrees)
		local direction = Vector3.new(
			desired.X * math.cos(angle) - desired.Z * math.sin(angle), 0,
			desired.X * math.sin(angle) + desired.Z * math.cos(angle))
		candidates[#candidates + 1] = { direction = direction, score = direction:Dot(desired) }
	end
	local selected = nil
	for _, candidate in ipairs(candidates) do
		if safeDirection(position, candidate.direction) then selected = candidate.direction break end
	end
	if not selected then stopMovement() S.navigation = "Blocked" return end

	if S.navigationCheck and now - S.navigationCheck >= 0.7 then
		if S.navigationPosition and (position - S.navigationPosition).Magnitude < 0.5 and next(movementKeys) then
			stopMovement()
			S.nextNavigation = now + 0.8
			S.navigationCheck = nil
			S.navigation = "Replanning"
			return
		end
		S.navigationCheck, S.navigationPosition = now, position
	elseif not S.navigationCheck then
		S.navigationCheck, S.navigationPosition = now, position
	end

	local wanted = {}
	local longitudinal, lateral = selected:Dot(forward), selected:Dot(right)
	if longitudinal > 0.4 then wanted.W = true elseif longitudinal < -0.4 then wanted.S = true end
	if lateral > 0.4 then wanted.D = true elseif lateral < -0.4 then wanted.A = true end
	for key in pairs(movementKeys) do if not wanted[key] then keyrelease(key) end end
	for key in pairs(wanted) do if not movementKeys[key] then robloxInput(true) keypress(key) end end
	movementKeys = wanted
	S.navigation = "Positioning"
end

local function press(now)
 S.curveSign = -(S.curveSign or 1)
	S.departed = false
	S.departureSince = nil
	S.minimumDistance = S.motionDistance
	curveAim()
	S.keyName = cfg.key
	if cfg.input == 2 then
		mouse1click()
	else
		tapParryKey(now)
	end
	S.lastPress = now
	S.presses += 1
end

local function releaseIfDue(now)
	if S.keyDown and now - S.keyAt >= 0.03 then
		sendParryKey(false)
		S.keyDown = false
		S.lastKeyRelease = now
	end
end

local function parryCount()
	local ok, n = pcall(function() return tonumber(lp.PlayerGui.ParryCounter.BG.CounterLabel.Text) end)
	return ok and n or nil
end

local function isAlive(char)
	if not char or not char.Parent then return false end
	local alive = workspace:FindFirstChild("Alive")
	if alive then return char.Parent == alive end
	local hum = char:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function realBalls()
	local out = {}
	local folder = workspace:FindFirstChild("Balls")
	if not folder then return out end
	for _, b in ipairs(folder:GetChildren()) do
		if b:IsA("BasePart") and not b.Anchored and b:GetAttribute("realBall") ~= false then
			out[#out + 1] = b
		end
	end
	return out
end

local accelOf = {}
local function ballAccel(b, s, now)
	local key = b.Address
	local h = accelOf[key]
	if not h then h = { t = now, s = s, a = 0 } accelOf[key] = h return 0 end
	local dt = now - h.t
	if dt >= 0.15 then
		local ds = s - h.s
		if h.s > 1 and math.abs(ds) > 0.25 * h.s then
			h.a = 0
		else
			local a = math.clamp(ds / dt, 0, 250)
			h.a = h.a + (a - h.a) * 0.5
		end
		h.t, h.s = now, s
	end
	return h.a
end

local function arrive(dist, v, a)
	if dist <= 0 then return 0 end
	v = math.max(v, 1)
	if a < 1 then return dist / v end
	return (-v + math.sqrt(v * v + 2 * a * dist)) / a
end

local function zoneRadius(speed)
	return math.min(cfg.zbase + cfg.zspd * speed, 140)
end

local D = BBX.draw
local function mk(kind, props)
	local d = Drawing.new(kind)
	for k, v in pairs(props) do d[k] = v end
	d.Visible = false
	D[#D + 1] = d
	return d
end

local BG = Color3.fromRGB(12, 14, 19)
local TRACK = Color3.fromRGB(34, 38, 48)
local WHITE = Color3.fromRGB(236, 240, 245)
local MUTED = Color3.fromRGB(185, 194, 209)
local OK_C = Color3.fromRGB(70, 225, 150)
local HOT = Color3.fromRGB(255, 78, 92)
local WARN = Color3.fromRGB(255, 196, 70)

local W, H = 342, 148
local hud = {
	bg = mk("Square", { Filled = true, Color = BG, Transparency = 0.92, Corner = 14, Size = Vector2.new(W, H), ZIndex = 20 }),
	edge = mk("Square", { Filled = false, Color = ACCENT, Thickness = 1, Transparency = 0.55, Corner = 14, Size = Vector2.new(W, H), ZIndex = 21 }),
	dot = mk("Circle", { Filled = true, Radius = 6, NumSides = 20, Color = OK_C, ZIndex = 22 }),
	state = mk("Text", { Size = 15, Font = 1, Outline = true, Color = WHITE, ZIndex = 22 }),
	info = mk("Text", { Size = 13, Outline = true, Center = false, Color = MUTED, ZIndex = 22 }),
	stats = mk("Text", { Size = 13, Outline = true, Center = false, Color = MUTED, ZIndex = 22 }),
}
hud.title = mk("Text", { Size = 12, Outline = true, Color = MUTED, ZIndex = 22 })
hud.navigation = mk("Text", { Size = 12, Outline = true, Color = MUTED, ZIndex = 22 })
hud.timing = mk("Text", { Size = 22, Outline = true, Color = WHITE, ZIndex = 22 })
hud.keys = mk("Text", { Size = 12, Color = MUTED, ZIndex = 22 })
local hudList = {}
for _, d in pairs(hud) do hudList[#hudList + 1] = d end

local RING_N = 40
local ring = {}
for i = 1, RING_N do ring[i] = mk("Line", { Thickness = 2, Transparency = 0.85, Color = ACCENT, ZIndex = 5 }) end
local rangeRing = {}
for i = 1, RING_N do rangeRing[i] = mk("Line", { Thickness = 1, Transparency = 0.7, Color = WARN, ZIndex = 4 }) end
local ballRing = mk("Circle", { Filled = false, Thickness = 2, NumSides = 28, Radius = 14, Color = HOT, ZIndex = 6 })
local ballText = mk("Text", { Size = 13, Outline = true, Center = true, Color = WHITE, ZIndex = 6 })
local ballLine = mk("Line", { Thickness = 2, Transparency = 0.8, Color = HOT, ZIndex = 5 })

local shown = { hud = false, ring = false, ball = false }
local function setVis(list, v) for _, d in ipairs(list) do if d.Visible ~= v then d.Visible = v end end end
local function r(n) return math.floor(n + 0.5) end
local function setText(d, t) if d.Text ~= t then d.Text = t end end
local SHORT_KEY = {
	RightShift = "RShift", LeftShift = "LShift", RightControl = "RCtrl", LeftControl = "LCtrl",
	RightAlt = "RAlt", LeftAlt = "LAlt", MouseButton2 = "M2", MouseButton3 = "M3",
	MouseButton4 = "M4", MouseButton5 = "M5", CapsLock = "Caps",
}
local function settingEnabled(key)
	if not key then return true end
	if key == "bbx_play_v4" or key == "bbx_curve_v4" then return settings[key] == true end
	return settings[key] ~= false
end

local function prettyKey(name)
	if not name or name == "" then return "None" end
	return SHORT_KEY[name] or name
end
local function clipText(text, maxLen)
	text = tostring(text or "")
	if #text <= maxLen then return text end
	return string.sub(text, 1, maxLen - 2) .. ".."
end

local menuPage = "Play"
local captureBind = nil
local previousKeys = {}
local previousMouse = false
local pages = {
	Play = {
		{"toggle", "Auto parry", "bbx_on"},
		{"choice", "Input", "bbx_input_v3", {"System key", "Mouse click"}},
		{"choice", "Game parry key", "bbx_key", KEYS},
		{"toggle", "Auto curve aim", "bbx_curve_v4"},
		{"toggle", "Auto play movement", "bbx_play_v4"},
		{"toggle", "Show keybind list", "bbx_keys_visible"}
	},
	Timing = {
		{"number", "Earlier input / ms", "bbx_offset", -60, 200, 5},
		{"toggle", "Latency compensation", "bbx_ping"},
		{"number", "Base zone / studs", "bbx_zbase", 8, 40, 1},
		{"number", "Zone growth / 100 speed", "bbx_zspd", 0, 30, 1},
		{"toggle", "Movement compensation", "bbx_move"},
		{"toggle", "Outcome logging", "bbx_log"}
	},
	Movement = {
		{"choice", "Curve direction", "bbx_curve_side", {"Alternate", "Left", "Right"}},
		{"number", "Curve angle", "bbx_curve_angle", 0, 55, 5},
		{"number", "Opponent spacing / studs", "bbx_spacing", 8, 35, 1},
		{"toggle", "Ball marker", "bbx_ball"},
		{"toggle", "World timing ring", "bbx_ring"},
		{"toggle", "Session HUD", "bbx_hud"},
		{"choice", "HUD position", "bbx_hudpos", {"Top right", "Bottom right"}}
	},
	Keybinds = {
		{"bind", "Open controls", "menu"},
		{"bind", "Auto parry", "parry"},
		{"bind", "Session HUD", "hud"},
		{"bind", "Auto play", "play"}
	}
}
local menuDraw = {}
local function menuObject(kind, properties)
	local object = mk(kind, properties)
	menuDraw[#menuDraw + 1] = object
	return object
end
local panel = menuObject("Square", {Filled=true,Color=Color3.fromRGB(16,19,26),Corner=12,ZIndex=100})
local sidebar = menuObject("Square", {Filled=true,Color=Color3.fromRGB(22,27,38),Corner=10,ZIndex=101})
local contentLine = menuObject("Square", {Filled=true,Color=Color3.fromRGB(40,48,64),Corner=0,ZIndex=102})
local brand = menuObject("Text", {Text="Blade Ball",Size=22,Outline=true,Color=WHITE,ZIndex=103})
local tagline = menuObject("Text", {Text="Auto parry",Size=11,Outline=true,Color=MUTED,ZIndex=103})
local pageTitle = menuObject("Text", {Size=20,Outline=true,Color=WHITE,ZIndex=103})
local pageHint = menuObject("Text", {Size=12,Outline=true,Color=MUTED,ZIndex=103})
local menuFooter = menuObject("Text", {Size=11,Outline=true,Color=MUTED,ZIndex=103})
local closeButton = menuObject("Text", {Text="x",Size=16,Outline=true,Color=MUTED,ZIndex=103})
local nav = {}
for _, name in ipairs({"Play", "Timing", "Movement", "Keybinds"}) do
	nav[#nav + 1] = {
		name=name,
		bg=menuObject("Square",{Filled=true,Color=TRACK,Corner=7,ZIndex=102}),
		text=menuObject("Text",{Text=name,Size=14,Outline=true,Color=WHITE,ZIndex=103})
	}
end
local rowPool = {}
for i = 1, 8 do
	rowPool[i] = {
		bg=menuObject("Square",{Filled=true,Color=Color3.fromRGB(28,34,46),Corner=8,ZIndex=102}),
		label=menuObject("Text",{Size=14,Outline=true,Color=WHITE,ZIndex=103}),
		value=menuObject("Text",{Size=13,Outline=true,Color=ACCENT,ZIndex=103}),
		minus=menuObject("Text",{Text="-",Size=18,Outline=true,Color=MUTED,ZIndex=103}),
		plus=menuObject("Text",{Text="+",Size=16,Outline=true,Color=MUTED,ZIndex=103})
	}
end
local BIND_PANEL_W, BIND_PANEL_H, BIND_ROW_H = 292, 168, 30
local bindPanel = mk("Square", {Filled=true,Color=BG,Corner=10,ZIndex=30,Size=Vector2.new(BIND_PANEL_W,BIND_PANEL_H)})
local bindTitle = mk("Text", {Text="Keybinds",Size=13,Outline=true,Color=WHITE,ZIndex=31})
local bindHeadKey = mk("Text", {Text="Key",Size=11,Outline=true,Color=MUTED,ZIndex=31})
local bindHeadState = mk("Text", {Text="State",Size=11,Outline=true,Color=MUTED,ZIndex=31})
local bindRows = {}
for _, spec in ipairs({
	{"Controls","menu",nil},{"Auto parry","parry","bbx_on"},
	{"HUD","hud","bbx_hud"},{"Auto play","play","bbx_play_v4"}
}) do
	bindRows[#bindRows + 1] = {
		spec=spec,
		text=mk("Text",{Size=12,Outline=true,Color=MUTED,ZIndex=31}),
		key=mk("Text",{Size=12,Outline=true,Color=WHITE,ZIndex=31}),
		state=mk("Text",{Size=11,Outline=true,Color=OK_C,ZIndex=31})
	}
end
local function over(mouse, x, y, w, h)
	return mouse.X >= x and mouse.X <= x+w and mouse.Y >= y and mouse.Y <= y+h
end
local keyNames = {
	"RightShift","LeftShift","RightControl","LeftControl","RightAlt","LeftAlt",
	"Space","Tab","Enter","Escape","Backspace","Insert","Delete","Home","End",
	"PageUp","PageDown","Up","Down","Left","Right","CapsLock",
	"MouseButton2","MouseButton3","MouseButton4","MouseButton5",
}
for i = 1, 12 do keyNames[#keyNames + 1] = "F" .. i end
for i = 65, 90 do keyNames[#keyNames + 1] = string.char(i) end
for i = 48, 57 do keyNames[#keyNames + 1] = string.char(i) end
local function controlsStep()
	local changed = {}
	for _, name in ipairs(keyNames) do
		local down = iskeydown(name)
		changed[name] = down and not previousKeys[name]
		previousKeys[name] = down
	end
	if captureBind then
		for _, name in ipairs(keyNames) do
			if changed[name] then
				if name ~= "Escape" then
					local duplicate = name == cfg.key or name == "W" or name == "A" or name == "S" or name == "D"
					for id, bound in pairs(binds) do if id ~= captureBind and bound == name then duplicate = true end end
					if not duplicate then binds[captureBind] = name captureBind = nil end
				else captureBind = nil end
				break
			end
		end
	elseif changed[binds.menu] then
		setMenu(not menuOpen)
	elseif not menuOpen and (not isrbxactive or isrbxactive()) then
		local toggles = {parry="bbx_on",hud="bbx_hud",play="bbx_play_v4"}
		for action,key in pairs(toggles) do
			if changed[binds[action]] then settings[key] = not settings[key] refresh() end
		end
	end
	if menuOpen and changed.Escape then captureBind=nil setMenu(false) end

	local view = workspace.CurrentCamera
	if not view then return end
	local vp = view.ViewportSize
	local mouse = getmouseposition()
	local mouseDown = ismouse1pressed()
	local clicked = mouseDown and not previousMouse
	previousMouse = mouseDown
	pcall(function() hostUI.SetMenuOpen(menuOpen) end)
	setVis(menuDraw, menuOpen)
	if menuOpen then
		local w = math.min(720, vp.X - 28)
		local h = math.min(520, vp.Y - 28)
		local x, y = math.floor((vp.X - w) / 2), math.floor((vp.Y - h) / 2)
		local sideW, rowH, rowGap = 152, 44, 8
		local contentX, contentW = x + sideW + 14, w - sideW - 28
		local valueW, valueX = 124, x + w - 132
		panel.Position, panel.Size = Vector2.new(x, y), Vector2.new(w, h)
		sidebar.Position, sidebar.Size = Vector2.new(x + 12, y + 12), Vector2.new(sideW, h - 24)
		contentLine.Position = Vector2.new(x + sideW + 12, y + 12)
		contentLine.Size = Vector2.new(1, h - 24)
		contentLine.Visible = true
		brand.Position = Vector2.new(x + 26, y + 26)
		tagline.Position = Vector2.new(x + 26, y + 52)
		pageTitle.Position = Vector2.new(contentX, y + 22)
		pageTitle.Text = menuPage
		pageHint.Position = Vector2.new(contentX, y + 48)
		pageHint.Text = menuPage == "Play" and "Enable features and choose how parry is sent to the game."
			or menuPage == "Keybinds" and "Click a row, press a key. Escape cancels binding."
			or menuPage == "Movement" and "Curve aim and spacing adjust before parry timing."
			or "Click a row to toggle. Use minus or plus on number rows."
		closeButton.Position = Vector2.new(x + w - 28, y + 20)
		if clicked and over(mouse, x + w - 40, y + 14, 32, 32) then setMenu(false) end
		for i, item in ipairs(nav) do
			local ny = y + 96 + (i - 1) * 44
			item.bg.Position = Vector2.new(x + 18, ny)
			item.bg.Size = Vector2.new(sideW - 12, 38)
			item.bg.Color = menuPage == item.name and Color3.fromRGB(54, 70, 102) or Color3.fromRGB(24, 29, 40)
			item.text.Position = Vector2.new(x + 30, ny + 11)
			if clicked and over(mouse, x + 18, ny, sideW - 12, 38) then
				menuPage = item.name
				captureBind = nil
			end
		end
		local rows = pages[menuPage]
		local listTop = y + 88
		for i, row in ipairs(rowPool) do
			local spec = rows and rows[i]
			local ry = listTop + (i - 1) * (rowH + rowGap)
			local visible = spec ~= nil and ry + rowH < y + h - 40
			for _, object in pairs(row) do object.Visible = visible end
			if visible then
				row.bg.Position = Vector2.new(contentX, ry)
				row.bg.Size = Vector2.new(contentW, rowH)
				row.label.Position = Vector2.new(contentX + 14, ry + 14)
				row.label.Text = clipText(spec[2], 28)
				row.value.Position = Vector2.new(valueX, ry + 14)
				row.minus.Visible = spec[1] == "number"
				row.plus.Visible = spec[1] == "number"
				if spec[1] == "toggle" then
					row.value.Text = settings[spec[3]] and "On" or "Off"
					row.value.Color = settings[spec[3]] and OK_C or MUTED
				elseif spec[1] == "choice" then
					local choice = spec[4][(settings[spec[3]] or 0) + 1] or spec[4][1]
					row.value.Text = clipText(choice, 16)
					row.value.Color = ACCENT
				elseif spec[1] == "bind" then
					row.value.Text = captureBind == spec[3] and "Press key" or prettyKey(binds[spec[3]])
					row.value.Color = captureBind == spec[3] and WARN or ACCENT
				else
					row.value.Text = tostring(settings[spec[3]])
					row.value.Position = Vector2.new(valueX - 34, ry + 14)
					row.minus.Position = Vector2.new(x + w - 88, ry + 10)
					row.plus.Position = Vector2.new(x + w - 46, ry + 11)
				end
				if clicked and over(mouse, contentX, ry, contentW, rowH) then
					if spec[1] == "toggle" then
						settings[spec[3]] = not settings[spec[3]]
					elseif spec[1] == "choice" then
						settings[spec[3]] = ((settings[spec[3]] or 0) + 1) % #spec[4]
					elseif spec[1] == "bind" then
						captureBind = spec[3]
					elseif spec[1] == "number" then
						local direction = mouse.X < x + w - 96 and -1 or 1
						settings[spec[3]] = math.clamp(settings[spec[3]] + direction * spec[6], spec[4], spec[5])
					end
					refresh()
				end
			end
		end
		menuFooter.Position = Vector2.new(contentX, y + h - 28)
		menuFooter.Text = prettyKey(binds.menu) .. " menu  |  Esc close  |  Parry paused while open"
	else
		contentLine.Visible = false
	end

	local show = settings.bbx_keys_visible ~= false and not menuOpen
	bindPanel.Visible = show
	bindTitle.Visible = show
	bindHeadKey.Visible = show
	bindHeadState.Visible = show
	local bx = math.max(14, vp.X - BIND_PANEL_W - 16)
	local by = math.max(14, vp.Y - BIND_PANEL_H - 16)
	if cfg.hudBottom then by = math.min(by, vp.Y - BIND_PANEL_H - 168) end
	bindPanel.Position = Vector2.new(bx, by)
	bindTitle.Position = Vector2.new(bx + 14, by + 10)
	bindHeadKey.Position = Vector2.new(bx + 168, by + 10)
	bindHeadState.Position = Vector2.new(bx + 236, by + 10)
	for i, row in ipairs(bindRows) do
		row.text.Visible = show
		row.key.Visible = show
		row.state.Visible = show
		if show then
			local ry = by + 36 + (i - 1) * BIND_ROW_H
			row.text.Position = Vector2.new(bx + 14, ry)
			row.key.Position = Vector2.new(bx + 168, ry)
			row.state.Position = Vector2.new(bx + 236, ry)
			row.text.Text = clipText(row.spec[1], 16)
			row.key.Text = prettyKey(binds[row.spec[2]])
			local active = settingEnabled(row.spec[3])
			local paused = active and row.spec[3] and (row.spec[2] == "parry" or row.spec[2] == "play")
				and (menuOpen or (isrbxactive and not isrbxactive()))
			row.state.Text = paused and "Pause" or (active and "On" or "Off")
			row.state.Color = paused and WARN or (active and OK_C or MUTED)
		end
	end
end

local sinceRefresh = 0
local function step(dt)
 controlsStep()
	sinceRefresh += dt
	if sinceRefresh > 0.25 then sinceRefresh = 0 refresh() end
	local now = os.clock()
	releaseIfDue(now)

	if now - S.pingAt > 1 then
		S.pingAt = now
		local p = getping and getping()
		if type(p) == "number" and p > 0 then S.rtt = p / 1000 end
	end
	if BBX.resetStats then
		BBX.resetStats = false
		S.ok, S.fail, S.presses, S.confirmSum, S.confirmN, S.unknown = 0, 0, 0, 0, 0, 0
	end
	if BBX.test then
 BBX.test = false
 if not S.pending and now - S.lastPress >= 0.7 then press(now) end
 end

	local char = lp.Character
	local root = char and char:FindFirstChild("HumanoidRootPart")
	local alive = root ~= nil and isAlive(char)
	local myPos = root and root.Position
	if char and S.character ~= char.Address then
		if S.pending then
			S.pending.out = "CHARACTER CHANGED"
			S.unknown += 1
			S.pending = nil
		end
		S.character = char.Address
		for _, attempt in ipairs(S.awaiting or {}) do
			attempt.out = "CHARACTER CHANGED"
			S.unknown += 1
		end
		S.awaiting = {}
		S.motionBall, S.motionDistance, S.motionTime = nil, nil, nil
		S.approach, S.returnAt, S.departed, S.lostTargetAt = nil, nil, false, nil
 S.afterConfirm = false
		S.armed = alive
	end

	if root and cfg.move then
		local v = root.AssemblyLinearVelocity
		S.myVel = S.myVel:Lerp(Vector3.new(v.X, v.Y * 0.5, v.Z), 0.4)
	else
		S.myVel = Vector3.zero
	end

	local highlighted = alive and char:FindFirstChildOfClass("Highlight") ~= nil
 local targeted = false
	local best = nil
	if myPos then
		for _, b in ipairs(realBalls()) do
			local tgt = b:GetAttribute("target")
			local mine = tgt == lp.Name
			mine = mine or tgt == lp.UserId or tostring(tgt) == tostring(lp.UserId)
 local hasTarget = tgt ~= nil and tgt ~= ""
 local ballMine = alive and (mine or (not hasTarget and highlighted))
 if ballMine then targeted = true end
			local P = myPos - b.Position
			local d = P.Magnitude
			local v = b.AssemblyLinearVelocity
			local s = v.Magnitude
			local rel = v - S.myVel
			local c = d > 0.01 and rel:Dot(P / d) or 0
			local R = zoneRadius(s)
			local acc = ballAccel(b, s, now)
			local tZone, tClose = math.huge, math.huge
			if c > 0.3 * math.max(s, 1) then tClose = arrive(d - R, c, acc) tZone = tClose end
			if c > -0.5 * s and s > 1 then tZone = math.min(tZone, arrive(d - R, s, acc)) end
			local coming = c > 0.2 * math.max(s, 1)
			if d <= R and coming then tZone, tClose = 0, 0 end
			local info = { coming = coming, b = b, d = d, s = s, c = c, R = R, tZone = tZone, tClose = tClose, acc = acc, mine = ballMine, pos = b.Position }
			if not best or (info.mine and not best.mine) or (info.mine == best.mine and tZone < best.tZone) then best = info end
		end
	end

	targeted = alive and best ~= nil and best.mine

 if best and targeted then
		local away = 0
		if myPos and best.d > 0.01 then away = S.myVel:Dot((myPos - best.pos) / best.d) end
		S.snap = string.format("d=%.1f spd=%.0f closing=%.0f zone=%.1f tZone=%.0fms me moving %+.0f st/s (+ = away from ball)", best.d, best.s, best.c, best.R, math.min(best.tZone, 9.99) * 1000, away)
	end

	if not alive then
		S.approach, S.departed, S.lostTargetAt = nil, false, nil
		S.armed = false
	elseif best then
		if S.approach ~= best.b.Address then
			S.approach = best.b.Address
			S.minimumDistance = best.d
			S.departed = false
 S.departureSince = nil
			S.lostTargetAt = nil
			S.armed = S.pending == nil
		end
		if not targeted then
			S.lostTargetAt = S.lostTargetAt or now
		else
			if S.lostTargetAt and now - S.lostTargetAt >= 0.12 then
				S.armed = S.pending == nil
			end
			S.lostTargetAt = nil
		end
		local sampleDt = S.motionTime and now - S.motionTime or 0
		local sameBall = S.motionBall == best.b.Address
		local delta = sameBall and S.motionDistance and best.d - S.motionDistance or 0
		S.minimumDistance = math.min(S.minimumDistance or best.d, best.d)
		local outwardTravel = best.d - S.minimumDistance
		local departureDistance = math.clamp(best.s * 0.012, 3, 8)
		local separated = outwardTravel >= departureDistance and best.s >= math.max(cfg.minspd, 20)
		local positionAway = sampleDt > 0 and delta > math.max(0.5, best.s * sampleDt * 0.2)
		local positionComing = sampleDt > 0 and delta < -math.max(0.25, best.s * sampleDt * 0.1)
		local velocityAway = best.c < -math.max(best.s * 0.2, 2)
		if sameBall and (positionAway or velocityAway) then
			S.departureSince = S.departureSince or now
			if separated and (positionAway or now - S.departureSince >= 0.018) then S.departed = true end
		elseif best.coming and positionComing and S.departed then
			S.departed = false
			S.returnAt = now
			S.departureSince = nil
			S.armed = S.pending == nil
		elseif not velocityAway then
			S.departureSince = nil
		end
		S.motionBall, S.motionDistance, S.motionTime = best.b.Address, best.d, now
	end

	S.lastDistance = best and best.d or nil
	local cnt = parryCount()
	local frame = {
		t = now, dt = dt, alive = alive, target = targeted, armed = S.armed,
		pending = S.pending ~= nil, counter = cnt, input = cfg.input,
 menu = menuOpen, enabled = cfg.on,
		focus = not isrbxactive or isrbxactive(),
		ball = best and best.b.Address, distance = best and best.d,
		speed = best and best.s, closing = best and best.c,
		departed = S.departed, afterConfirm = S.afterConfirm
	}
	S.trace[#S.trace + 1] = frame
	if #S.trace > 120 then table.remove(S.trace, 1) end
	S.awaiting = S.awaiting or {}
	for i = #S.awaiting, 1, -1 do
		local attempt = S.awaiting[i]
		local confirmed = cnt ~= nil and attempt.expected ~= nil and cnt >= attempt.expected
		if confirmed or not alive or now - attempt.t > math.max(0.8, S.rtt * 2 + 0.5) then
			if confirmed then
				S.ok += 1
				S.confirmN += 1
				S.confirmSum += now - attempt.t
				attempt.out = "CONFIRMED"
			else
				S.unknown += 1
				attempt.out = "UNCONFIRMED"
			end
			table.remove(S.awaiting, i)
		end
	end
	local pend = S.pending
	if cnt ~= nil and S.observedCounter ~= nil and cnt < S.observedCounter then
		for _, attempt in ipairs(S.awaiting) do
			attempt.out = "ROUND RESET"
			S.unknown += 1
		end
		S.awaiting = {}
		if pend then pend.cnt, pend.expected = cnt, cnt + 1 end
	end
	S.observedCounter = cnt
	if pend then
		local confirmed = cnt ~= nil and pend.expected ~= nil and cnt >= pend.expected
		if confirmed or not alive or now - pend.t > math.max(0.8, S.rtt * 2 + 0.5) then
			if confirmed then
				S.ok += 1
				S.confirmN += 1
				S.confirmSum += now - pend.t
 S.confirmedAt = now
 S.confirmedDistance = best and best.d or 0
 S.afterConfirm = false
				pend.out = "CONFIRMED"
				S.flash, S.flashOk = now, true
			elseif not alive then
				S.fail += 1
				pend.out = "MISS"
 captureFailure("died with an input pending")
				S.flash, S.flashOk = now, false
			else
				S.unknown += 1
				pend.out = "UNCONFIRMED"
			end
			if cfg.log then print("[bbx] " .. pend.out .. " " .. historyText(now)) end
			S.pending = nil
			if confirmed then
				S.armed = alive and S.returnAt ~= nil and S.returnAt >= pend.t
			else
				S.armed = alive
			end
			S.releasedAt = now
		end
	end
	if S.wasAlive and not alive then
		S.deaths = (S.deaths or 0) + 1
		if S.wasTargeted and not pend and cfg.on then
			if S.inputWasActive then
				S.fail += 1
				captureFailure("died without a pending input")
			else
				S.pausedDeaths = (S.pausedDeaths or 0) + 1
				captureFailure("died while input was paused")
			end
		end
	end
	S.inputWasActive = cfg.on and not menuOpen and (not isrbxactive or isrbxactive())
	if not alive and S.keyDown then sendParryKey(false) S.keyDown = false end
	S.wasAlive, S.wasTargeted = alive, targeted

	local window = math.clamp(0.16 + (cfg.ping and S.rtt or 0) + math.min(dt, 0.05) + cfg.offset, 0.06, 0.40)
 local focused = not isrbxactive or isrbxactive()
	robloxInput(focused and not menuOpen)
	if targeted and alive and not S.pending and not S.armed and S.returnAt and now >= S.returnAt then
		S.armed = true
	end
	local canPress = cfg.on and focused and not menuOpen and S.armed and not S.pending
		and (cfg.input == 2 or now - (S.lastKeyRelease or -math.huge) >= 0.018)
		and now - S.lastPress >= 0.12
	if cfg.curve and cfg.on and alive and focused and not menuOpen then
		curveAim()
	elseif not cfg.curve or menuOpen then
		restoreCamera()
	end
	local status
	if not cfg.on then
		status = "OFF"
	elseif not alive then
		status = "WAITING"
 elseif menuOpen then
 status = "CONTROLS OPEN"
 elseif not focused then
 status = "FOCUS ROBLOX"
	elseif not best then
		status = "NO BALL"
	elseif not targeted then
		status = "SAFE"
	elseif best.s < cfg.minspd then
		status = "HOLD"
	else
		status = "TARGETED"
		local inZone = best.d <= best.R and best.coming
		local notTooEarly = best.coming and best.tClose <= math.min(window + 0.06, 0.42)
		if canPress and ((best.tZone <= window and notTooEarly) or inZone) then
			S.armed = false
			S.afterConfirm = false
			S.pending = remember({ t = now, cnt = cnt, expected = cnt and (cnt + #S.awaiting + 1), d = best.d, s = best.s, c = best.c, R = best.R, tz = best.tZone, win = window,
				acc = best.acc, gap = now - S.lastPress, why = inZone and "zone" or (S.lastExpired and now - S.lastExpired < 0.2 and "after-expiry" or "timing") })
			press(now)
			status = "PARRY"
		elseif S.pending then
			status = "PARRY"
		end
	end
	if cfg.on and focused and not menuOpen and cfg.rangeOn and alive and best then
		local d = math.huge
		if targeted and best.coming then
			d = best.d
		end
		if d <= cfg.range and canPress and now - S.lastPress > 0.15 then
			S.armed = false
			S.afterConfirm = false
			S.pending = remember({ t = now, cnt = cnt, expected = cnt and (cnt + #S.awaiting + 1), d = best.d, s = best.s, c = best.c, R = best.R, tz = best.tZone, win = window,
				acc = best.acc, gap = now - S.lastPress, range = true, why = "range" })
			press(now)
			status = "RANGE"
		end
	end
	autoPlay(now, root, alive, best, targeted, focused and not menuOpen)
	S.status = status

	local col = ((status == "PARRY" or status == "RANGE") and WARN) or (status == "TARGETED" and HOT)
		or ((status == "OFF" or status == "WAITING" or status == "NO BALL") and MUTED) or OK_C
	if now - S.flash < 0.25 then col = S.flashOk and OK_C or HOT end

	camera = workspace.CurrentCamera
 local hudOn = cfg.hud and camera ~= nil
	if shown.hud ~= hudOn then shown.hud = hudOn setVis(hudList, hudOn) end
	if hudOn then
		local vp = camera.ViewportSize
		local x = math.max(12, vp.X - W - 24)
		local y = cfg.hudBottom and math.max(10, vp.Y - H - (cfg.showKeys and 240 or 48)) or 82
		hud.bg.Position = Vector2.new(x, y)
		hud.edge.Position = Vector2.new(x, y)
		hud.edge.Color = TRACK
		hud.dot.Position = Vector2.new(x + 14, y + 20)
		hud.dot.Radius = 4
		hud.dot.Color = col
		hud.state.Position = Vector2.new(x + 28, y + 11)
		hud.state.Size = 15
		hud.state.Color = WHITE
		local labels = {
			PARRY = "Parry sent",
			TARGETED = "Incoming",
			SAFE = "Watching",
			WAITING = "Waiting round",
			["NO BALL"] = "No ball",
			OFF = "Paused",
			HOLD = "Tracking",
			["CONTROLS OPEN"] = "Menu open",
			["FOCUS ROBLOX"] = "Focus game",
		}
		setText(hud.state, clipText(labels[status] or status, 22))
		hud.title.Position = Vector2.new(x + W - 108, y + 12)
		hud.title.Size = 12
		setText(hud.title, "Auto parry")
		hud.timing.Position = Vector2.new(x + 12, y + 34)
		hud.timing.Size = 22
		setText(hud.timing, best and best.coming and best.tClose < math.huge and string.format("%d ms", best.tClose * 1000) or "Ready")
		hud.info.Position = Vector2.new(x + 12, y + 60)
		hud.info.Size = 13
		setText(hud.info, best and string.format("Speed %.0f   Dist %.0f", best.s, best.d) or "Waiting for ball")
		hud.stats.Position = Vector2.new(x + 12, y + 84)
		hud.stats.Size = 13
		setText(hud.stats, string.format("Ok %d   Miss %d   ? %d", S.ok, S.fail, S.unknown))
		hud.navigation.Position = Vector2.new(x + 12, y + 106)
		setText(hud.navigation, "Move " .. clipText(S.navigation or "Off", 14) .. "   Curve " .. (cfg.curve and "On" or "Off"))
		hud.keys.Visible = false

	end

	local rangeOn = cfg.rangeOn and cfg.rangeRing and alive and myPos ~= nil
	if rangeOn then
		local base = myPos - Vector3.new(0, 2.9, 0)
		local prev, prevOn
		for i = 0, RING_N do
			local a = (i / RING_N) * math.pi * 2
			local p, on = worldtoscreen(base + Vector3.new(math.cos(a) * cfg.range, 0, math.sin(a) * cfg.range))
			if i > 0 then
				local l = rangeRing[i]
				if on and prevOn then
					l.From = Vector2.new(r(prev.X), r(prev.Y))
					l.To = Vector2.new(r(p.X), r(p.Y))
					if not l.Visible then l.Visible = true end
				elseif l.Visible then
					l.Visible = false
				end
			end
			prev, prevOn = p, on
		end
		shown.range = true
	elseif shown.range then
		setVis(rangeRing, false)
		shown.range = false
	end

	local ringOn = cfg.ring and alive and myPos ~= nil and best ~= nil
	if ringOn then
		local R = best.R
		local base = myPos - Vector3.new(0, 2.9, 0)
		local prev, prevOn
		for i = 0, RING_N do
			local a = (i / RING_N) * math.pi * 2
			local p, on = worldtoscreen(base + Vector3.new(math.cos(a) * R, 0, math.sin(a) * R))
			if i > 0 then
				local l = ring[i]
				if on and prevOn then
					l.From = Vector2.new(r(prev.X), r(prev.Y))
					l.To = Vector2.new(r(p.X), r(p.Y))
					l.Color = targeted and col or cfg.accent
					if not l.Visible then l.Visible = true end
				elseif l.Visible then
					l.Visible = false
				end
			end
			prev, prevOn = p, on
		end
		shown.ring = true
	elseif shown.ring then
		setVis(ring, false)
		shown.ring = false
	end

	local ballOn = cfg.ball and best ~= nil
	if ballOn then
		local p, on = worldtoscreen(best.pos)
		if on then
			local rad = math.clamp(900 / math.max(best.d, 10), 6, 36)
			ballRing.Position = Vector2.new(r(p.X), r(p.Y))
			if ballRing.Radius ~= r(rad) then ballRing.Radius = r(rad) end
			ballRing.Color = targeted and col or OK_C
			ballText.Position = Vector2.new(r(p.X), r(p.Y - rad - 18))
			setText(ballText, targeted and string.format("%.0f ms", math.min(best.tZone, 9.99) * 1000) or "")
			ballRing.Visible, ballText.Visible = true, targeted
			if targeted and myPos then
				local m, mOn = worldtoscreen(myPos)
				ballLine.Visible = mOn
				if mOn then
					ballLine.From = Vector2.new(r(m.X), r(m.Y))
					ballLine.To = Vector2.new(r(p.X), r(p.Y))
					ballLine.Color = col
				end
			else
				ballLine.Visible = false
			end
			shown.ball = true
		else
			ballOn = false
		end
	end
	if not ballOn and shown.ball then
		ballRing.Visible, ballText.Visible, ballLine.Visible = false, false, false
		shown.ball = false
	end
end

BBX.conns[#BBX.conns + 1] = RunService.Heartbeat:Connect(function(dt)
	local ok, err = pcall(step, dt)
	if not ok then stopMovement() restoreCamera() end
	if not ok and os.clock() - (BBX.lastErr or 0) > 2 then
		BBX.lastErr = os.clock()
		warn("Blade Ball: " .. tostring(err))
	end
end)

BBX.stats = S
BBX.unload = function()
	robloxInput(false)
 restoreCamera()
	stopMovement()
	for _, c in ipairs(BBX.conns) do pcall(function() c:Disconnect() end) end
	if S.keyDown then pcall(sendParryKey, false) end
	for _, d in ipairs(D) do pcall(function() d:Remove() end) end
	setMenu(false)
	getgenv().BBX = nil
end

notify("Loaded. Press " .. binds.menu .. " for controls.", "bladeball autoparry", 3)
print("bladeball autoparry loaded")
