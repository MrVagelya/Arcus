local GAMES = { [66654135] = true, [9271746647] = true }
if not GAMES[game.GameId] then
	notify("This script only runs in Murder Mystery 2", "MM2", 4)
	return
end

local G = getgenv()
if G.MM2_UNLOAD then pcall(G.MM2_UNLOAD) end

local ID = "mm2_"
local S, ids, conns = {}, {}, {}
local alive = true

local function rgb(r, g, b) return Color3.fromRGB(r, g, b) end

local THEME = {
	Accent = rgb(110, 90, 255), Background = rgb(18, 18, 26), Text = rgb(235, 235, 245),
	Transparency = 0.04, Rounding = 8,
}

local function sync()
	for key, id in pairs(ids) do
		local v = UI.GetValue(id)
		if v ~= nil then S[key] = v end
	end
end

local function reg(key, default)
	ids[key] = ID .. key
	if S[key] == nil then S[key] = default end
	return ID .. key
end

local function toggle(sec, key, label, default, tip)
	local id = reg(key, default)
	sec:Toggle(id, label, default, function() S[key] = UI.GetValue(id) end)
	if tip then sec:Tooltip(tip) end
end

local function slider(sec, key, label, min, max, default)
	local id = reg(key, default)
	sec:SliderInt(id, label, min, max, default, function() S[key] = UI.GetValue(id) end)
end

local function color(sec, key, label, default)
	local id = reg(key, default)
	sec:ColorPicker(id, label, default, function() S[key] = UI.GetValue(id) end)
end

local function combo(sec, key, label, options, default)
	local id = reg(key, default)
	sec:Combo(id, label, options, default, function() S[key] = UI.GetValue(id) end)
end

local function setFarm(on)
	S.farm = on
	UI.SetValue(ID .. "farm", on)
end

UI.SetTitle("MM2")
UI.SetTheme(THEME)
UI.SetSize(560, 420)

UI.AddTab("Farm", function(tab)
	local a = tab:Section("Collector", "Left")
	toggle(a, "farm", "Auto farm coins", false, "Collects coins during a round")
	a:Keybind(ID .. "farm_key", "Toggle key", "F6", function() setFarm(not S.farm) end)
	combo(a, "mode", "Mode", { "Fly", "Touch" }, 0)
	slider(a, "speed", "Fly speed", 10, 35, 35)
	slider(a, "cruise", "Fly height above coins", 4, 40, 14)
	toggle(a, "noclip", "Noclip while flying", true)
	local b = tab:Section("Priorities", "Right")
	toggle(b, "grab", "Take dropped gun first", false, "Only when you are an innocent")
	toggle(b, "safe", "Pause near murderer", false, "Stops moving when the murderer is close")
	slider(b, "saferange", "Pause distance", 10, 100, 30)
	slider(b, "maxCoins", "Stop farm at bag count (0 = never)", 0, 50, 50)
end)

UI.AddTab("Visuals", function(tab)
	local a = tab:Section("Players", "Left")
	toggle(a, "esp", "Player ESP", true)
	toggle(a, "box", "Boxes", true)
	toggle(a, "name", "Names and roles", true)
	toggle(a, "health", "Health bars", true)
	toggle(a, "dist", "Distance", true)
	toggle(a, "tracer", "Tracers", false)
	toggle(a, "only", "Murderer and sheriff only", false)
	slider(a, "range", "Max distance", 100, 5000, 2000)
	local b = tab:Section("Colors", "Right")
	color(b, "cMurderer", "Murderer", rgb(255, 70, 70))
	color(b, "cSheriff", "Sheriff", rgb(80, 150, 255))
	color(b, "cInnocent", "Innocent", rgb(90, 230, 120))
	color(b, "cCoin", "Coins", rgb(255, 215, 0))
	color(b, "cGun", "Gun drop", rgb(0, 205, 255))
	b:Separator()
	b:Group("World")
	toggle(b, "coins", "Coin ESP", true)
	toggle(b, "coinline", "Line to nearest coin", true)
	toggle(b, "gun", "Gun drop ESP", true)
	b:EndGroup()
	b:Group("Overlay")
	toggle(b, "panel", "Info panel", true)
	toggle(b, "warn", "Murderer warning", true)
	slider(b, "warnrange", "Warning distance", 10, 150, 40)
	b:EndGroup()
end)

UI.AddTab("Player", function(tab)
	local a = tab:Section("Movement", "Left")
	toggle(a, "speedOn", "Walk speed boost", false, "Sets your WalkSpeed while on (16 is normal)")
	slider(a, "walkspeed", "Walk speed", 16, 60, 24)
	toggle(a, "antiafk", "Anti AFK", true, "Taps a key every few minutes so Roblox does not kick you for idling")
	local b = tab:Section("Gun", "Right")
	b:Button("Fly to dropped gun", function() G.MM2_GRAB_GUN = true end)
	b:Tooltip("Flies to the gun drop at your fly speed and picks it up")
end)

-- Key names the Keybind widget gives back, as Windows virtual-key codes for UI.SetMenuKey.
local VK = {
	Space = 0x20, Enter = 0x0D, Tab = 0x09, Backspace = 0x08, Escape = 0x1B, CapsLock = 0x14,
	LeftShift = 0xA0, RightShift = 0xA1, LeftControl = 0xA2, RightControl = 0xA3, LeftAlt = 0xA4, RightAlt = 0xA5,
	Insert = 0x2D, Delete = 0x2E, Home = 0x24, End = 0x23, PageUp = 0x21, PageDown = 0x22,
	Left = 0x25, Up = 0x26, Right = 0x27, Down = 0x28,
	MouseButton2 = 0x02, MouseButton3 = 0x04, MouseButton4 = 0x05, MouseButton5 = 0x06,
}
for i = 1, 12 do VK["F" .. i] = 0x6F + i end
for c = string.byte("A"), string.byte("Z") do VK[string.char(c)] = c end
for d = 0, 9 do VK[tostring(d)] = 0x30 + d end

local function applyMenuKey(name)
	local vk = name and VK[name]
	if vk then UI.SetMenuKey(vk) end
end

UI.AddTab("Settings", function(tab)
	local a = tab:Section("Menu", "Left")
	a:Keybind(ID .. "menu_key", "Menu key", "RightShift", nil, function()
		applyMenuKey(UI.GetValue(ID .. "menu_key"))
	end)
	a:Tooltip("Click it, then press the key that should open and close this menu")
	a:Button("Unload", function() if G.MM2_UNLOAD then G.MM2_UNLOAD() end end)
end)
applyMenuKey(UI.GetValue(ID .. "menu_key"))

sync()
local MAX_FLY_SPEED = 35
local function flySpeed()
	return math.clamp(tonumber(S.speed) or 35, 10, MAX_FLY_SPEED)
end
if (tonumber(S.speed) or 0) > MAX_FLY_SPEED then
	S.speed = MAX_FLY_SPEED
	pcall(UI.SetValue, ID .. "speed", MAX_FLY_SPEED)
end

local WHITE, BLACK = rgb(255, 255, 255), rgb(0, 0, 0)
local DIM, GOOD = rgb(150, 150, 170), rgb(80, 220, 120)
local MAXP, MAXC = 24, 80

local function sq(filled)
	local o = Drawing.new("Square")
	o.Filled = filled
	o.Visible = false
	return o
end
local function ln(thickness)
	local o = Drawing.new("Line")
	o.Thickness = thickness or 1
	o.Visible = false
	return o
end
local function tx(size, center)
	local o = Drawing.new("Text")
	o.Size = size
	o.Center = center
	o.Outline = true
	o.Font = Drawing.Fonts.UI
	o.Visible = false
	return o
end

local pool = {}
for i = 1, MAXP do
	local e = {
		shadow = sq(false), box = sq(false), name = tx(13, true), dist = tx(12, true),
		hpBack = sq(true), hp = sq(true), tracer = ln(1),
	}
	e.shadow.Thickness = 3
	e.shadow.Color = BLACK
	e.shadow.Transparency = 0.6
	e.box.Thickness = 1
	e.hpBack.Color = BLACK
	e.hpBack.Transparency = 0.6
	pool[i] = e
end

local coinDots = {}
for i = 1, MAXC do
	local c = Drawing.new("Circle")
	c.Radius = 4
	c.Filled = true
	c.NumSides = 12
	c.Visible = false
	coinDots[i] = c
end

local coinLine, gunLine = ln(1), ln(1)
local gunLabel = tx(14, true)
local warnBack = sq(true)
warnBack.Corner = 8
warnBack.Color = rgb(40, 10, 14)
warnBack.Transparency = 0.85
warnBack.Size = Vector2.new(260, 38)
local warnText = tx(20, true)
warnText.Color = rgb(255, 90, 90)

local ROWS = { "Role", "Murderer", "Sheriff", "Coins", "Bag", "Farm" }
local panel = sq(true)
panel.Corner = 8
panel.Color = rgb(18, 18, 26)
panel.Transparency = 0.9
panel.Position = Vector2.new(20, 300)
panel.Size = Vector2.new(210, 62 + #ROWS * 17)
local accent = sq(true)
accent.Corner = 2
accent.Position = Vector2.new(28, 308)
accent.Size = Vector2.new(194, 3)
local title = tx(15, false)
title.Position = Vector2.new(28, 316)
title.Color = WHITE
title.Text = "MM2"
local rowLabels, rowValues = {}, {}
for i, name in ipairs(ROWS) do
	local l = tx(13, false)
	l.Position = Vector2.new(28, 318 + i * 17)
	l.Color = DIM
	l.Text = name
	local v = tx(13, false)
	v.Position = Vector2.new(112, 318 + i * 17)
	v.Color = WHITE
	rowLabels[i], rowValues[i] = l, v
end

local lp = game.Players.LocalPlayer
local roles, coins, gunDrop = {}, {}, nil
local visited = {}
local nextTouch, hold = 0, 0
local touchPart, touchAt, touchBag = nil, 0, 0
local chaseId, chaseSince, chaseLimit = nil, 0, 3.5
local bagSerial = 0
local lastChar, charParts = nil, {}
local current = nil
local bag, stalled = nil, 0

local function bagIsFull()
	local cap = S.maxCoins
	if cap == nil then cap = 50 end
	if cap <= 0 then return false end
	return bag ~= nil and bag >= cap
end

local function loop(interval, fn)
	task.spawn(function()
		while alive do
			pcall(fn)
			task.wait(interval)
		end
	end)
end

local function roleFor(p)
	if p:HasTool("Knife") then return "Murderer" end
	if p:HasTool("Gun") then return "Sheriff" end
	return "Innocent"
end

loop(0.3, function()
	local r = {}
	for _, p in ipairs(PlayerCache.GetPlayers()) do r[p.Name] = roleFor(p) end
	roles = r
end)

local function coinId(part) return part and part.Address end

local function isCoin(part)
	return part and part.Name == "Coin_Server" and part.Parent ~= nil
end

-- Every property read here is a read from the game process, so the coin code keeps what does not change:
-- each coin's MainCoin is looked up once, positions are read by the scan (coins never move), and the
-- per-frame ESP only draws the scan's list without touching the game.
local mainCoinOf = {}
local function mainCoin(part)
	local key = part.Address
	local main = mainCoinOf[key]
	if main then return main end
	local visual = part:FindFirstChild("CoinVisual")
	main = visual and visual:FindFirstChild("MainCoin")
	if main then mainCoinOf[key] = main end
	return main
end

-- Coin_Server is MM2's invisible hitbox (always Transparency 1), so its own transparency says nothing.
-- What you see is CoinVisual.MainCoin: it turns fully transparent (and the visual goes away) once the coin is taken.
local function visualGone(part)
	local main = mainCoin(part)
	if not main or main.Parent == nil then return true end
	local ok, tr = pcall(function() return main.Transparency end)
	return ok and tr ~= nil and tr >= 0.99
end

local function coinGone(part)
	if not isCoin(part) then return true end
	if visualGone(part) then return true end
	local ok2, sz = pcall(function() return part.Size end)
	if ok2 and sz and sz.Magnitude < 0.05 then return true end
	return false
end

local function coinCollectible(part)
	return isCoin(part) and not coinGone(part)
end

local function partAlive(part)
	if not part or part.Parent == nil then return false end
	if part.Name == "Coin_Server" then return not coinGone(part) end
	local ok, alive = pcall(function() return part:IsValid() end)
	return not ok or alive ~= false
end

local function markVisited(entry, now, secs)
	if not entry then return end
	local key = entry.id or entry.part
	if key then visited[key] = now + (secs or 6) end
end

-- The CoinContainer is found once per map. The old scan searched every workspace child recursively
-- (and walked the whole map with GetDescendants when that missed) eight times a second; one recursive
-- search over the workspace costs about 40 ms, so it now only runs when the shallow lookup fails,
-- at most every 10 s.
local DEEP_SEARCH_EVERY = 10
local container, containerMap = nil, nil
local lastDeepSearch, lastGunSearch = 0, 0
local coinKind = {} -- address -> true for Coin_Server children, false for anything else

local function findContainer(now)
	if container and container.Parent ~= nil then return container end
	container, containerMap = nil, nil
	local children = workspace:GetChildren()
	for _, m in ipairs(children) do
		local cc = m:FindFirstChild("CoinContainer")
		if cc then container, containerMap = cc, m return cc end
	end
	if now - lastDeepSearch >= DEEP_SEARCH_EVERY then
		lastDeepSearch = now
		for _, m in ipairs(children) do
			local cc = m:FindFirstChild("CoinContainer", true)
			if cc then container, containerMap = cc, m return cc end
		end
	end
	return nil
end

loop(0.1, function()
	local now = tick()
	local drop = nil
	for _, m in ipairs(workspace:GetChildren()) do
		if m.Name == "GunDrop" then drop = m break end
	end
	local cc = findContainer(now)
	if not drop and containerMap then drop = containerMap:FindFirstChild("GunDrop") end
	-- The gun drops into the map model, which the line above already checks; the recursive search is only
	-- for maps found without a CoinContainer.
	if not drop and not containerMap and now - lastGunSearch >= DEEP_SEARCH_EVERY then
		lastGunSearch = now
		for _, m in ipairs(workspace:GetChildren()) do
			drop = m:FindFirstChild("GunDrop", true)
			if drop then break end
		end
	end

	local list = {}
	if cc then
		local seen = {}
		for _, c in ipairs(cc:GetChildren()) do
			local key = c.Address
			seen[key] = true
			local kind = coinKind[key]
			if kind == nil then
				kind = c.Name == "Coin_Server"
				coinKind[key] = kind
			end
			if kind and not visualGone(c) then
				list[#list + 1] = { part = c, pos = c.Position, id = key }
			end
		end
		for key in pairs(coinKind) do
			if not seen[key] then coinKind[key] = nil; mainCoinOf[key] = nil end
		end
	end
	coins = list

	if drop and drop.Parent and partAlive(drop) then
		gunDrop = { part = drop, pos = drop.Position, id = coinId(drop) }
	else
		gunDrop = nil
	end
	for key, until_ in pairs(visited) do
		if until_ < now then visited[key] = nil end
	end
end)

local bagLabel = nil
loop(0.25, function()
	if not bagLabel or bagLabel.Parent == nil then
		bagLabel = nil
		local frame = lp.PlayerGui.MainGUI.Game.CoinBags.Container.Coin
		for _, d in ipairs(frame:GetDescendants()) do
			if d.Name == "Coins" then bagLabel = d break end
		end
	end
	local value = bagLabel and tonumber(bagLabel.Text)
	if value ~= bag then
		if bag == nil or value == nil or value < bag then stalled = 0 end
		if value and bag and value > bag then
			stalled = 0
			bagSerial = bagSerial + 1
			current = nil
			touchPart, touchAt, chaseId = nil, 0, nil
		end
		bag = value
	end
end)

local function roleColor(role)
	if role == "Murderer" then return S.cMurderer end
	if role == "Sheriff" then return S.cSheriff end
	return S.cInnocent
end

local savedCollide = {} -- part address -> CanCollide before noclip, restored when flight stops
local function refreshParts(char)
	charParts = {}
	for _, d in ipairs(char:GetDescendants()) do
		if d:IsA("BasePart") then
			charParts[#charParts + 1] = d
			local key = d.Address
			if savedCollide[key] == nil then
				local ok, v = pcall(function() return d.CanCollide end)
				savedCollide[key] = { part = d, value = ok and v or false }
			end
		end
	end
	lastChar = char
end

local function restoreCollision()
	for _, saved in pairs(savedCollide) do
		if saved.value then pcall(function() if saved.part.Parent then saved.part.CanCollide = true end end) end
	end
	savedCollide = {}
end

local function pickTarget(pos, now)
	local best, bestDist = nil, math.huge
	for _, c in ipairs(coins) do
		local key = c.id or c.part
		if (visited[key] or 0) >= now then continue end
		local d = (c.pos - pos).Magnitude
		if d < bestDist then best, bestDist = c, d end
	end
	return best
end

local function stillValid(t, now)
	if not t then return false end
	local key = t.id or t.part
	if (visited[key] or 0) >= now then return false end
	if not partAlive(t.part) then return false end
	if gunDrop and t.part == gunDrop.part then
		if coinCollectible(t.part) or t.part.Name == "GunDrop" then
			t.pos = t.part.Position
			return true
		end
		return false
	end
	if not coinCollectible(t.part) then return false end
	for _, c in ipairs(coins) do
		if c.id == t.id or c.part == t.part then
			t.pos = c.pos
			return true
		end
	end
	return false
end

local anchoredChar
local heldHum, savedEval, savedRotate
local partRefresh = 0
-- The flight keeps its own position. It used to step from root.Position every frame, and the game pulled the body
-- down between frames (gravity, with collisions off), so each step started lower: it sank through the map and never
-- climbed. Now root.CFrame is written from this position every frame, and gravity never builds up.
local flyPos, flyRoot = nil, nil

local function releaseAnchor()
	if flyPos and flyRoot then
		pcall(function()
			flyRoot.AssemblyLinearVelocity = Vector3.zero
			flyRoot.AssemblyAngularVelocity = Vector3.zero
		end)
	end
	flyPos, flyRoot = nil, nil
	if next(savedCollide) ~= nil then restoreCollision() end
	if anchoredChar then
		local root = anchoredChar:FindFirstChild("HumanoidRootPart")
		if root then root.Anchored = false end
		anchoredChar = nil
	end
	if heldHum then
		heldHum.EvaluateStateMachine = savedEval ~= false
		heldHum.AutoRotate = savedRotate ~= false
		heldHum = nil
	end
end

local function holdFlight(char)
	local hum = char:FindFirstChildOfClass("Humanoid")
	if not hum then return end
	if heldHum ~= hum then
		if heldHum then
			heldHum.EvaluateStateMachine = savedEval ~= false
			heldHum.AutoRotate = savedRotate ~= false
		end
		savedEval = hum.EvaluateStateMachine
		savedRotate = hum.AutoRotate
		heldHum = hum
	end
	hum.EvaluateStateMachine = false
	hum.AutoRotate = false
end

local function clearCollision(char, now)
	if char ~= lastChar or now >= partRefresh then
		refreshParts(char)
		partRefresh = now + 0.2
	end
	for i = 1, #charParts do
		charParts[i].CanCollide = false
	end
end

local function farmStep(dt, me, myRole, murdererDist)
	local char = me.Character
	local pos = me.Position
	local toGun = G.MM2_GUN_TRIP and G.MM2_GUN_TRIP() and gunDrop ~= nil
	if not char or not pos or (me.Health or 0) <= 0 or (bagIsFull() and not toGun) or not char:FindFirstChild("HumanoidRootPart") then releaseAnchor() return end
	if not toGun and S.safe and murdererDist <= S.saferange and myRole ~= "Murderer" then releaseAnchor() return end
	local now = tick()
	if toGun then
		if not current or current.part ~= gunDrop.part then current = gunDrop end
		current.pos = gunDrop.pos
	elseif not current or not stillValid(current, now) then
		if S.grab and gunDrop and myRole == "Innocent" and (visited[gunDrop.id or gunDrop.part] or 0) < now then
			current = gunDrop
		else
			current = pickTarget(pos, now)
		end
	end
	if not current then chaseId = nil releaseAnchor() return end
	local ckey = current.id or current.part
	-- Give up on a target that is not reached in time. The time allowed grows with the distance, since the fly
	-- speed is capped at 50 and far coins take a while.
	if chaseId ~= ckey then
		chaseId, chaseSince = ckey, now
		chaseLimit = 3.5 + (current.pos - pos).Magnitude / flySpeed()
	end
	if now - (chaseSince or now) > (chaseLimit or 3.5) then
		markVisited(current, now, 12)
		current, touchPart, touchAt, chaseId = nil, nil, 0, nil
		return
	end
	local dist = (current.pos - pos).Magnitude
	if S.mode == 1 then
		releaseAnchor()
		if now >= nextTouch then
			local root = char:FindFirstChild("HumanoidRootPart")
			if root then
				firetouchinterest(root, current.part, nil, 0.3)
				markVisited(current, now, 3)
				nextTouch = now + 0.45
				stalled = stalled + 1
				current = nil
			end
		end
	else
		local root = char:FindFirstChild("HumanoidRootPart")
		if not root then releaseAnchor() return end
		holdFlight(char)
		if S.noclip then clearCollision(char, now) end
		local live = root.Position
		-- Start (or restart after a respawn, a teleport or the game moving us) from where the body really is.
		if not flyPos or flyRoot ~= root or (live - flyPos).Magnitude > 12 then
			flyPos, flyRoot = live, root
		end
		local here = flyPos
		local flat = Vector3.new(current.pos.X - here.X, 0, current.pos.Z - here.Z)
		local flatDist = flat.Magnitude
		-- Far away: travel at cruise height above both ends. Close: come straight down onto the coin.
		local blend = math.clamp((flatDist - 6) / 20, 0, 1)
		local cruise = math.max(here.Y, current.pos.Y) + (S.cruise or 14)
		local goal = Vector3.new(current.pos.X, current.pos.Y * (1 - blend) + cruise * blend, current.pos.Z)
		local function hold()
			root.CFrame = CFrame.new(flyPos)
			root.AssemblyLinearVelocity = Vector3.zero
			root.AssemblyAngularVelocity = Vector3.zero
		end
		if touchPart == current.part and now < touchAt then
			if not coinCollectible(current.part) and current.part.Name == "Coin_Server" then
				markVisited(current, now, 10)
				touchPart, touchAt, current, chaseId = nil, 0, nil, nil
				hold()
				return
			end
			if touchBag ~= bagSerial then
				markVisited(current, now, 1.5)
				touchPart, touchAt, current, chaseId = nil, 0, nil, nil
				hold()
				return
			end
			hold()
		elseif touchPart == current.part and now >= touchAt then
			if touchBag ~= bagSerial then
				markVisited(current, now, 1.5)
			else
				markVisited(current, now, 10)
			end
			touchPart, touchAt, current, chaseId = nil, 0, nil, nil
			hold()
		elseif flatDist < 4 and math.abs(here.Y - current.pos.Y) < 4 then
			if touchPart ~= current.part then
				local hit = current.part
				if hit and not hit:IsA("BasePart") then hit = hit:FindFirstChildWhichIsA("BasePart") end
				if hit then firetouchinterest(root, hit, nil, 0.2) end
				touchPart = current.part
				touchAt = now + 0.2
				touchBag = bagSerial
			elseif touchBag ~= bagSerial then
				markVisited(current, now, 8)
				touchPart, touchAt, current, chaseId = nil, 0, nil, nil
			elseif not coinCollectible(current.part) then
				markVisited(current, now, 10)
				touchPart, touchAt, current, chaseId = nil, 0, nil, nil
			else
				markVisited(current, now, 2.5)
				stalled = stalled + 1
				touchPart, touchAt, current, chaseId = nil, 0, nil, nil
			end
			hold()
		else
			touchPart = nil
			local delta = goal - here
			local remain = delta.Magnitude
			if remain > 0.05 then
				local stepDt = dt
				if stepDt <= 0 or stepDt > 0.05 then stepDt = 1 / 60 end
				local step = math.min(flySpeed() * stepDt, remain)
				flyPos = here + delta * (step / remain)
			end
			hold()
		end
	end
end

local function hidePlayer(e)
	for _, o in pairs(e) do o.Visible = false end
end

local playersShown, coinsShown = MAXP, MAXC
local function drawPlayers(me, sw, sh)
	local used = 0
	local nearestMurderer = math.huge
	local myPos = me and me.Position
	for _, p in ipairs(PlayerCache.GetPlayers()) do
		local pp = p.Position
		if not p.IsLocal and pp then
			local role = roles[p.Name] or "Innocent"
			local d = myPos and (pp - myPos).Magnitude or 0
			if role == "Murderer" and d < nearestMurderer then nearestMurderer = d end
			if S.esp and used < MAXP and d <= S.range and not (S.only and role == "Innocent") then
				local top, bottom, ok = p:GetEspBounds()
				if ok then
					local ts, onTop = worldtoscreen(top)
					local bs, onBottom = worldtoscreen(bottom)
					if onTop and onBottom then
						used = used + 1
						local e = pool[used]
						local col = roleColor(role)
						local h = math.abs(bs.Y - ts.Y)
						local w = h * 0.5
						local cx = (ts.X + bs.X) / 2
						local pos = Vector2.new(cx - w / 2, ts.Y)
						local size = Vector2.new(w, h)
						e.shadow.Visible = S.box
						e.box.Visible = S.box
						if S.box then
							e.shadow.Position, e.shadow.Size = pos, size
							e.box.Position, e.box.Size, e.box.Color = pos, size, col
						end
						e.name.Visible = S.name
						if S.name then
							e.name.Text = role == "Innocent" and p.Name or (p.Name .. "  " .. role)
							e.name.Color = col
							e.name.Position = Vector2.new(cx, ts.Y - 17)
						end
						local showHp = S.health and (p.MaxHealth or 0) > 0
						e.hpBack.Visible, e.hp.Visible = showHp, showHp
						if showHp then
							local f = math.clamp(p.Health / p.MaxHealth, 0, 1)
							e.hpBack.Position = Vector2.new(pos.X - 6, pos.Y)
							e.hpBack.Size = Vector2.new(3, h)
							e.hp.Color = rgb(math.floor(255 * (1 - f)), math.floor(235 * f), 70)
							e.hp.Position = Vector2.new(pos.X - 6, pos.Y + h * (1 - f))
							e.hp.Size = Vector2.new(3, h * f)
						end
						e.dist.Visible = S.dist
						if S.dist then
							e.dist.Text = string.format("%dm", math.floor(d))
							e.dist.Color = WHITE
							e.dist.Position = Vector2.new(cx, bs.Y + 2)
						end
						e.tracer.Visible = S.tracer
						if S.tracer then
							e.tracer.Color = col
							e.tracer.From = Vector2.new(sw / 2, sh)
							e.tracer.To = Vector2.new(cx, bs.Y)
						end
					end
				end
			end
		end
	end
	for i = used + 1, playersShown do hidePlayer(pool[i]) end
	playersShown = used
	return nearestMurderer
end

local function drawWorld(myPos, sw, sh)
	local shown = 0
	local near, nearDist = nil, math.huge
	local coinColor = S.cCoin
	for _, c in ipairs(coins) do
		if myPos then
			local d = (c.pos - myPos).Magnitude
			if d < nearDist then near, nearDist = c.pos, d end
		end
		if S.coins and shown < MAXC then
			local s, on = worldtoscreen(c.pos)
			if on then
				shown = shown + 1
				local dot = coinDots[shown]
				dot.Position = s
				dot.Color = coinColor
				dot.Visible = true
			end
		end
	end
	for i = shown + 1, coinsShown do coinDots[i].Visible = false end
	coinsShown = shown
	coinLine.Visible = false
	if S.coinline and near then
		local s, on = worldtoscreen(near)
		if on then
			coinLine.From, coinLine.To, coinLine.Color = Vector2.new(sw / 2, sh), s, S.cCoin
			coinLine.Visible = true
		end
	end
	gunLabel.Visible, gunLine.Visible = false, false
	if S.gun and gunDrop then
		local s, on = worldtoscreen(gunDrop.pos)
		if on then
			local d = myPos and (gunDrop.pos - myPos).Magnitude or 0
			gunLabel.Text = string.format("Gun  %dm", math.floor(d))
			gunLabel.Color = S.cGun
			gunLabel.Position = s
			gunLabel.Visible = true
			gunLine.From, gunLine.To, gunLine.Color = Vector2.new(sw / 2, sh), s, S.cGun
			gunLine.Visible = true
		end
	end
end

local function drawPanel(myRole)
	local on = S.panel
	panel.Visible, accent.Visible, title.Visible = on, on, on
	for i = 1, #ROWS do
		rowLabels[i].Visible, rowValues[i].Visible = on, on
	end
	if not on then return end
	local murderer, sheriff = "-", "-"
	for name, r in pairs(roles) do
		if r == "Murderer" then murderer = name elseif r == "Sheriff" then sheriff = name end
	end
	accent.Color = S.farm and GOOD or THEME.Accent
	rowValues[1].Text = myRole
	rowValues[2].Text = murderer
	rowValues[3].Text = sheriff
	rowValues[4].Text = tostring(#coins)
	local full = bagIsFull()
	rowValues[5].Text = bag and (full and (bag .. "  full") or tostring(bag)) or "-"
	rowValues[5].Color = full and rgb(255, 120, 90) or WHITE
	local farmText = "Off"
	if S.farm then farmText = full and "Paused" or (S.mode == 1 and "On  touch" or "On  fly") end
	rowValues[6].Text = farmText
	rowValues[6].Color = (S.farm and not full) and GOOD or DIM
end

local function drawWarning(myRole, murdererDist, sw)
	local show = S.warn and myRole ~= "Murderer" and murdererDist <= S.warnrange
	warnBack.Visible, warnText.Visible = show, show
	if show then
		warnBack.Position = Vector2.new(sw / 2 - 130, 100)
		warnText.Text = string.format("Murderer  %dm", math.floor(murdererDist))
		warnText.Position = Vector2.new(sw / 2, 108)
	end
end

local lastMurdererDist = math.huge

conns[#conns + 1] = RunService.RenderStepped:Connect(function()
	local me = PlayerCache.GetLocalPlayer()
	local sw, sh = draw.screensize()
	local myRole = me and roles[me.Name] or "Innocent"
	lastMurdererDist = drawPlayers(me, sw, sh)
	drawWorld(me and me.Position, sw, sh)
	drawPanel(myRole)
	drawWarning(myRole, lastMurdererDist, sw)
end)

conns[#conns + 1] = RunService.Heartbeat:Connect(function(dt)
	if not S.farm and not (G.MM2_GUN_TRIP and G.MM2_GUN_TRIP()) then
		current = nil
		releaseAnchor()
		return
	end
	local me = PlayerCache.GetLocalPlayer()
	if me then pcall(farmStep, dt, me, roles[me.Name] or "Innocent", lastMurdererDist) end
end)

-- Walk speed boost: written only while on, and put back to 16 once when turned off.
local speedWasOn = false
loop(0.25, function()
	local char = lp.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if not hum then return end
	if S.speedOn and not S.farm then
		hum.WalkSpeed = S.walkspeed or 24
		speedWasOn = true
	elseif speedWasOn then
		hum.WalkSpeed = 16
		speedWasOn = false
	end
end)

-- Anti AFK: Roblox kicks after 20 idle minutes; a short camera key tap every 4 minutes counts as input.
local lastAfkTap = os.clock()
loop(5, function()
	if not S.antiafk or not isrbxactive() then lastAfkTap = os.clock() return end
	if os.clock() - lastAfkTap < 240 then return end
	lastAfkTap = os.clock()
	setrobloxinput(true)
	keypress("I")
	task.wait(0.05)
	keyrelease("I")
	keypress("O")
	task.wait(0.05)
	keyrelease("O")
	setrobloxinput(false)
end)

-- Fly to the dropped gun (menu button). It uses the farm's flight, so it moves at the capped speed; a teleport
-- straight to the gun is the kind of jump the server kicks for.
local gunTrip, gunTripUntil = false, 0
loop(0.1, function()
	if G.MM2_GRAB_GUN then
		G.MM2_GRAB_GUN = false
		if not gunDrop then notify("No gun on the map", "MM2", 2) return end
		gunTrip, gunTripUntil = true, tick() + 20
		current, touchPart, touchAt, chaseId = nil, nil, 0, nil
	end
	if gunTrip and (not gunDrop or tick() > gunTripUntil) then
		gunTrip = false
		current = nil
	end
end)
G.MM2_GUN_TRIP = function() return gunTrip end

G.MM2_UNLOAD = function()
	alive = false
	releaseAnchor()
	if speedWasOn then pcall(function() lp.Character:FindFirstChildOfClass("Humanoid").WalkSpeed = 16 end) end
	for _, c in ipairs(conns) do c:Disconnect() end
	for _, e in ipairs(pool) do for _, o in pairs(e) do o:Remove() end end
	for _, c in ipairs(coinDots) do c:Remove() end
	for _, o in ipairs({ coinLine, gunLine, gunLabel, warnBack, warnText, panel, accent, title }) do o:Remove() end
	for i = 1, #ROWS do rowLabels[i]:Remove(); rowValues[i]:Remove() end
	UI.RemoveTab("Farm")
	UI.RemoveTab("Visuals")
	UI.RemoveTab("Player")
	UI.RemoveTab("Settings")
	G.MM2_UNLOAD = nil
end