-- Skins, icons, sounds, and gun animations are applied from the Arcus menu.
-- The Rivals Skinchanger tab is shown while you are in Rivals.
return
